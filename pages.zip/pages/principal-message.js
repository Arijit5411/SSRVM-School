import React, { Fragment, useState, useEffect } from "react";
import NavBar from "../components/NavBar";
import ReactMarkdown from "react-markdown";

import Footer from "../components/Footer";
import Head from "next/head";
// import Seo from './Seo';

import { determineStrapiUrl } from "@/utils/strapiUtils";
import Seo from "@/components/Seo";
import Image from "next/image";

export const getServerSideProps = async (context) => {
  try {
    const siteUrl = determineStrapiUrl(context);
    const res = await fetch(`${siteUrl}/api/seo?populate=deep,10`);

    const res1 = await fetch(`${siteUrl}/api/principal-s-messages?populate=*`);

    const data = await res.json();
    const data1 = await res1.json();

    return {
      props: {
        seodata: data?.data?.attributes?.Pages ?? {},
        principal_data: data1,
        siteUrl,
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error.message);

    return {
      props: {
        data: [],
      },
    };
  }
};

const PrincipalMessage = ({ seodata, principal_data, siteUrl }) => {
  const [principalData, setPrincipalData] = useState(null);
  const [loading, setLoading] = useState(true); // State for loading
 

  // useEffect(() => {
  //     fetch(`${siteUrl}/api/principal-s-messages?populate=*`)
  //         .then((response) => response.json())
  //         .then((data) => {
  //             setPrincipalData(data.data[0].attributes);
  //             setLoading(false);
  //         })
  //         .catch((error) => {
  //             console.error("Error:", error);
  //             setLoading(false);
  //         });
  // }, []);

  useEffect(() => {
    // Fetch SEO data from your API
    // fetch(`${siteUrl}/api/seos?pagination[start]=0&pagination[limit]=50`) // Replace with the actual API endpoint
    //     .then((response) => response.json())
    //     .then((data) => {
    //         console.log('API response data:', data); // Log the API response data
    //         if (data && data.data && data.data.length > 0) {
    //             const seoAttributes = data.data[2].attributes;
    //             setSeoData({
    //                 title: seoAttributes.title || '',
    //                 metaTitle: seoAttributes.metaTitle || '',
    //                 metaDescription: seoAttributes.metaDescription || '',
    //             });
    //         }
    //     })
    //     .catch((error) => {
    //         console.error('Error fetching SEO data:', error);
    //     });
    
    if (principal_data && principal_data?.data?.length > 0) {
      setPrincipalData(principal_data.data[0].attributes);
      setLoading(false);
    } else {
      setLoading(false);
    }
  }, []);

  const imageUrl = `${siteUrl}${principalData?.principal_image?.data?.attributes?.url}`;
  const pageTitle = `${principalData?.page_title}`;
  const principalName = `${principalData?.principal_name}`;
  const principalMessage = `${principalData?.principal_message}`;

  return (
    <>
          <Seo SeoData={seodata} PageSlug={"principal-message"} />

      <Fragment>
        <NavBar siteUrl={siteUrl} />
      

        {loading ? (
          <div className="loader">Loading...</div>
        ) : (
          <div style={{ minHeight: '100vh', padding: '160px 0 60px 0' }}>
            <div className="container">
              <h1 className="principal-mess">{pageTitle}</h1>
            </div>
            <section className="container">
              <div className="principal-mess-item">
                <div className="principal-image">
                  <Image width={300} height={400} src={imageUrl} alt="Transpro" className="wrap-img w-[100px]"/>
                  <h6 className="wrap-principal-mess-item">{principalName}</h6>
                </div>
                <p>
                  <ReactMarkdown >
                    {principalMessage}
                  </ReactMarkdown>
                </p>
              </div>
            </section>
          </div>
        )}
        <Footer siteUrl={siteUrl} />
      </Fragment>
    </>
  );
};

export default PrincipalMessage;
